package com.example.hp.sorting;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Spannable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button buttonSort;
    EditText t1;
    TextView v1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonSort = (Button) findViewById(R.id.button3);
        t1 = (EditText) findViewById(R.id.editText2);
        v1 = (TextView) findViewById(R.id.textView);

        buttonSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n=t1.getText().toString();
                String s[]=n.split(" ");
                BubbleSort(s);

            }
        });
    }

    public void BubbleSort (String str[]) {
        int length=str.length;
       int a[]=new int[str.length];
        for (int i = 0; i < length; i++) {
            a[i] = Integer.parseInt(str[i]);

        }
        for (int i = 0; i < length; i++) {
            for (int j = i + 1; j < length-1; j++) {
                if (a[i] > a[j]) {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;

                }
            }
        }


        for (int i = 0; i < length; i++) {
            v1.setText(v1.getText().toString() + Integer.toString(a[i]) + "\n");
        }



    }

}





